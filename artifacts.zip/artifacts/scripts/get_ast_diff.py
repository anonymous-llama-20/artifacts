from pathlib import Path
import subprocess
import csv
import subprocess
import json
import os
import shutil
import argparse

def get_diff(args):
    """Compare files in bugfix to get AST diff""" 
    rows = []
    # iterate over every bugfix
    for pr in os.listdir(args.dir_path):
        pr_path = Path(args.dir_path).joinpath(pr)
        if not pr_path.as_posix().endswith('^'):
            # iterate over every file in bugfix
            for file in os.listdir(pr_path):
                fixed_file_path = pr_path.joinpath(file)
                buggy_file_path = Path(pr_path.as_posix() + '^').joinpath(file)
                proc = subprocess.run(['./sv_diff', f'{buggy_file_path}', f'{fixed_file_path}'], capture_output=True, text=True)
                nodes = proc.stdout.splitlines()
                for node in nodes:
                    rows.append(
                        {
                            'pr_number': pr, 
                            'file': file, 
                            'node': node.split(':')[0], 
                            'count': node.split(':')[1], 
                        }
                    )
    # save data to output csv file
    with open(args.output_csv, newline='', mode='w') as csv_file:
        field_names = ['pr_number', 'file', 'node', 'count']
        writer = csv.DictWriter(csv_file, fieldnames=field_names)
        writer.writeheader()
        writer.writerows(rows)
    
visited = set()
def get_PR_files(args, url):
    # dont fetch files for the same PR multiple times
    if(url in visited):
        return
    visited.add(url)
    
    print(f"fetching {url}...")
    proc = subprocess.run(['gh', 'pr', 'view', '-R', 'https://github.com/lowRISC/opentitan', f'{url}', '--json', 'number,mergeCommit,files'], capture_output=True, text=True)
    resp_json = json.loads(proc.stdout)
    files_json = resp_json['files']
    pr_number = resp_json['number']
    merge_oid = resp_json['mergeCommit']['oid']
    new_path = Path(args.dir_path)
    
    os.chdir("opentitan")
    subprocess.run(['git', 'checkout', merge_oid])
    os.chdir("..")
    
    # copy all rtl design files involved in bugfix
    fixed_pr_path = new_path.joinpath(str(pr_number))
    os.mkdir(fixed_pr_path)
    for file in files_json:
        file_name = str(file['path']).split('/')[-1]
        ot_file_path = Path('opentitan').joinpath(file['path'])
        if os.path.exists(ot_file_path.as_posix()) and ot_file_path.as_posix().__contains__('/rtl/'):
            shutil.copy(ot_file_path.as_posix(), fixed_pr_path.as_posix())
            os.rename(fixed_pr_path.joinpath(file_name), fixed_pr_path.joinpath(str(file['path']).replace('/', '-')))
        
    os.chdir("opentitan")
    subprocess.run(['git', 'checkout', merge_oid + '^'])
    os.chdir("..")
    
    # copy all rtl design files involved in bugfix
    buggy_pr_path = new_path.joinpath(str(pr_number) + '^')
    os.mkdir(buggy_pr_path)
    for file in files_json:
        file_name = str(file['path']).split('/')[-1]
        ot_file_path = Path('opentitan').joinpath(file['path'])
        if os.path.exists(ot_file_path.as_posix()) and ot_file_path.as_posix().__contains__('/rtl/'):
            shutil.copy(ot_file_path.as_posix(), buggy_pr_path.as_posix())
            os.rename(buggy_pr_path.joinpath(file_name), buggy_pr_path.joinpath(str(file['path']).replace('/', '-')))
    
def main():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("dir_path")
    arg_parser.add_argument("input_csv")
    arg_parser.add_argument("output_csv")
    args = arg_parser.parse_args()
    
    # check that OpenTitan exists
    if not Path("opentitan").is_dir:
        print("could not find OpenTitan. Please clone OpenTitan 'git clone https://github.com/lowRISC/opentitan'")
        return
    
    # check that the data dir doesn't already exist
    # delete it if it does
    if os.path.exists(args.dir_path):
        shutil.rmtree(args.dir_path)
    os.mkdir(args.dir_path)
    
    # iterate bug (issues) data and get bugfix files
    with open(args.input_csv,  newline='') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            pr_url = row['PR URL']
            if pr_url != None and pr_url != '':
                get_PR_files(args, pr_url)
                
    # call sv_diff
    get_diff(args)
    
if __name__ == "__main__":
    main()