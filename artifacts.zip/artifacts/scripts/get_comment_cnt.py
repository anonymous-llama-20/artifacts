import subprocess
import csv
import json
import argparse

def main():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("input_csv")
    arg_parser.add_argument("output_csv")
    args = arg_parser.parse_args()
    with open(args.input_csv,  newline='') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        rows = []
        for row in csv_reader:
            number = row['number']
            url = row['URL']
            pr_url = row['PR URL']
            print(f"fetching {number}")
            # get issue comments
            proc = subprocess.run(['gh', 'issue', 'view', '-R', 'https://github.com/lowRISC/opentitan', f'{url}', '--json', 'comments'], capture_output=True, text=True)
            resp_json = json.loads(proc.stdout)
            issue_comment_count = len(resp_json['comments'])
            
            pr_comment_count = 0
            # get pr comments
            if pr_url != None and pr_url != '':
                proc = subprocess.run(['gh', 'pr', 'view', '-R', 'https://github.com/lowRISC/opentitan', f'{pr_url}', '--json', 'comments'], capture_output=True, text=True)
                resp_json = json.loads(proc.stdout)
                pr_comment_count = len(resp_json['comments'])
                
            rows.append({
                'issue number': number,
                'issue comment count': issue_comment_count,
                'pr comment count': pr_comment_count
            })
            
    with open(args.output_csv, newline='', mode='w') as csv_file:
        field_names = ['issue number', 'issue comment count', 'pr comment count']
        writer = csv.DictWriter(csv_file, fieldnames=field_names)
        writer.writeheader()
        writer.writerows(rows)
    
if __name__=='__main__':
    main()