# An Investigation of Hardware Security Bug Characteristics in Open-Source Projects

## Structure
```bash
OSS
├── Makefile    # makefile to compile visitor for AST traversal
├── README.md
├── data        # OpenTitan data collected
│   ├── ot_data.xlsx     # excel file containing "master table" and all other tables
│   ├── ast_diff.csv            # output csv from "get_ast_diff.py"    
│   ├── ot_comment_count.csv    # output csv from "get_comment_cnt.py"
│   └── ot_pr_data.csv          # output csv from "get_pr_data.py"
├── scripts     # scripts used to collect data
│   ├── README.md
│   ├── get_ast_diff.py         # computes the AST diff
│   ├── get_comment_cnt.py      # computes the comment count
│   └── get_pr_data.py          # computes the # of files/lines changed for a bug fix
└── src
    ├── DiffVisitor.hpp # AST visitor definition
    └── driver.cpp 
```

## Dependencies
1. Slang - https://sv-lang.com/building.html
2. python3 - ```apt install python3```
3. gh - https://formulae.brew.sh/formula/gh or ```apt install gh```
4. git - ```apt install git```